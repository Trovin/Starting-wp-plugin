// placeholder for javascript
jQuery('document').ready(function($){
  $(".js-range-slider").ionRangeSlider();
});
