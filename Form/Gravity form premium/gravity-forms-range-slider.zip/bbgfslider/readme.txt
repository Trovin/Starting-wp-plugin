=== Gravity Forms Slider Field Add-On ===
Tags: Gravity Forms Range Slider, Gravity Forms Slider Field
Tested up to: 5.1.1
Requires PHP: 5.3

 A highly interactive and customisable range slider field for gravity forms.
