wnumb
=====

wNumb - JavaScript Number &amp; Money formatting

# Documentation

Documentation and examples are available on [refreshless.com/wnumb](http://refreshless.com/wnumb/).

# License

Licensed [WTFPL](http://www.wtfpl.net/about/), so free for personal and commercial use.
